<?php 
$koneksi = mysqli_connect("localhost","n1608971_admin","Janggeunsuk123","n1608971_botble");
?>